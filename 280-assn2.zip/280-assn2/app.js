// app.js
document.getElementById('sendButton').addEventListener('click', function () {
    const prompt = document.getElementById('taxPrompt').value;

    // Validate that the prompt is not empty
    if (prompt.trim() === '') {
        alert('Please enter a tax-related question.');
        return;
    }
    const sqlite3 = require('sqlite3').verbose();
    const db = new sqlite3.Database('./auditHistory.db');
    
    // Existing setup and imports
    app.post('/tax-query', async (req, res) => {
        const { prompt } = req.body;
    
        try {
            const gptResponse = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    model: 'gpt-3.5-turbo',
                    messages: [{ role: 'user', content: prompt }]
                })
            });
    
            if (!gptResponse.ok) {
                throw new Error('Error fetching GPT response');
            }
    
            const gptData = await gptResponse.json();
            const responseText = gptData.choices[0].message.content;
    
            // Save the prompt and response to the database
            db.run(`INSERT INTO history (prompt, response) VALUES (?, ?)`, [prompt, responseText], function (err) {
                if (err) {
                    console.error('Error inserting into database:', err.message);
                    return res.status(500).json({ error: 'Database error' });
                }
    
                res.json({ response: responseText });
            });
    
        } catch (error) {
            console.error('Error calling GPT API:', error);
            res.status(500).json({ error: 'An error occurred while processing your request.' });
        }
    });
    app.get('/history', (req, res) => {
        db.all('SELECT * FROM history ORDER BY timestamp DESC LIMIT 10', [], (err, rows) => {
            if (err) {
                console.error('Error retrieving from database:', err.message);
                return res.status(500).json({ error: 'Database error' });
            }
    
            res.json(rows);
        });
    });
    db.close();
  
    
    
document.getElementById('cancelButton').addEventListener('click', function () {
    document.getElementById('taxPrompt').value = '';
    document.getElementById('response').innerText = '';
})});
document.getElementById('viewHistoryButton').addEventListener('click', async () => {
    try {
        const response = await fetch('http://localhost:3000/history');
        const history = await response.json();

        const historyList = document.getElementById('historyList');
        historyList.innerHTML = history.map(entry => `
            <div class="history-entry">
                <p><strong>Prompt:</strong> ${entry.prompt}</p>
                <p><strong>Response:</strong> ${entry.response}</p>
                <p><small>${new Date(entry.timestamp).toLocaleString()}</small></p>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error fetching history:', error);
        alert('An error occurred while fetching the history.');
    }
});

