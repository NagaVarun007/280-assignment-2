require('dotenv').config();

const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const dotenv = require('dotenv');


// Load environment variables from .env file
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.OPENAI_API_KEY;
const cors = require('cors');
app.use(cors());
// Middleware to parse JSON bodies
app.use(bodyParser.json());

// POST endpoint for tax queries
app.post('/tax-query', async (req, res) => {
    const { query } = req.body;

    if (!query || query.trim() === '') {
        return res.status(400).json({ error: 'Please provide a valid tax-related question.' });
    }

    try {
        console.log('Received query:', query);

        const response = await axios.post(
            'https://api.openai.com/v1/chat/completions',
            {
                model: 'gpt-3.5-turbo',
                messages: [
                    { role: 'system', content: 'You are a tax advisor specializing in US tax law.' },
                    { role: 'user', content: query }
                ],
                max_tokens: 100,
                temperature: 0.7
            },
            {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
                }
            }
        );

        console.log('Response from GPT:', response.data);

        const answer = response.data.choices[0].message.content;
        res.json({ answer });
    } catch (error) {
        console.error('Error calling the GPT API:', error.response?.data || error.message);
        res.status(500).json({ error: 'An error occurred while processing your request. Please try again later.' });
    }
});

console.log('API Key:', API_KEY);


// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

